/*
 *    Copyright (C) 2025 by YOUR NAME HERE
 *
 *    This file is part of RoboComp
 *
 *    RoboComp is free software: you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation, either version 3 of the License, or
 *    (at your option) any later version.
 *
 *    RoboComp is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with RoboComp.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "specificworker.h"
#include <cppitertools/itertools.hpp>


SpecificWorker::SpecificWorker(const ConfigLoader& configLoader, TuplePrx tprx, bool startup_check) : GenericWorker(configLoader, tprx)
{
	this->startup_check_flag = startup_check;
	if(this->startup_check_flag)
	{
		this->startup_check();
	}
	else
	{
		#ifdef HIBERNATION_ENABLED
			hibernationChecker.start(500);
		#endif
		
		// Example statemachine:
		/***
		//Your definition for the statesmachine (if you dont want use a execute function, use nullptr)
		states["CustomState"] = std::make_unique<GRAFCETStep>("CustomState", period, 
															std::bind(&SpecificWorker::customLoop, this),  // Cyclic function
															std::bind(&SpecificWorker::customEnter, this), // On-enter function
															std::bind(&SpecificWorker::customExit, this)); // On-exit function

		//Add your definition of transitions (addTransition(originOfSignal, signal, dstState))
		states["CustomState"]->addTransition(states["CustomState"].get(), SIGNAL(entered()), states["OtherState"].get());
		states["Compute"]->addTransition(this, SIGNAL(customSignal()), states["CustomState"].get()); //Define your signal in the .h file under the "Signals" section.

		//Add your custom state
		statemachine.addState(states["CustomState"].get());
		***/

		statemachine.setChildMode(QState::ExclusiveStates);
		statemachine.start();

		auto error = statemachine.errorString();
		if (error.length() > 0){
			qWarning() << error;
			throw error;
		}
	}
}

SpecificWorker::~SpecificWorker()
{
	std::cout << "Destroying SpecificWorker" << std::endl;
}


void SpecificWorker::initialize()
{
    std::cout << "initialize worker" << std::endl;

    //initializeCODE

    /////////GET PARAMS, OPEND DEVICES....////////
    //int period = configLoader.get<int>("Period.Compute") //NOTE: If you want get period of compute use getPeriod("compute")
    //std::string device = configLoader.get<std::string>("Device.name") 

	this->dimensions = QRectF(-6000, -3000, 12000, 6000);
	viewer = new AbstractGraphicViewer(this->frame, this->dimensions);
	this->resize(900,450);
	viewer->show();
	const auto rob = viewer->add_robot(ROBOT_LENGTH, ROBOT_LENGTH, 0, 190, QColor("Blue"));
	robot_polygon = std::get<0>(rob);

	connect(viewer, &AbstractGraphicViewer::new_mouse_coordinates, this, &SpecificWorker::new_target_slot);

}



void SpecificWorker::compute()
{
	std::optional<RoboCompLidar3D::TPoints> filter_data;

	// -----------------------
	// Leer LIDAR y filtrar
	// -----------------------
	try
	{
		auto data = lidar3d_proxy->getLidarDataWithThreshold2d("helios", 5000, 1);
		if(data.points.empty()) return;

		filter_data = filter_min_distance_cppitertools(data.points);
		draw_lidar(filter_data.value(), &viewer->scene);
	}
	catch(const Ice::Exception &e)
	{
		std::cout << "Error reading Lidar: " << e << std::endl;
		return;
	}

	// -----------------------
	// State machine
	// -----------------------
	float advance_speed = 0, rotation_speed = 0;
	std::tuple<RobotMode,float,float> result;

	switch(current_mode)
	{
		case RobotMode::FORWARD:
			result = FORWARD_method(filter_data);
			break;
		case RobotMode::FOLLOW_WALL:
			result = FOLLOW_WALL_method(filter_data);
			break;
		case RobotMode::SPIRAL:
			result = SPIRAL_method(filter_data);
			break;
		case RobotMode::TURN:
			result = TURN_method(filter_data);
			break;
		case RobotMode::IDLE:
		default:
			result = {RobotMode::IDLE, 0, 0};
			break;
	}

	// Actualizar el estado
	current_mode = std::get<0>(result);
	advance_speed = std::get<1>(result);
	rotation_speed = std::get<2>(result);

	// -----------------------
	// Enviar velocidades al robot
	// -----------------------
	try
	{
		omnirobot_proxy->setSpeedBase(0, advance_speed, rotation_speed);
	}
	catch(const Ice::Exception &e)
	{
		std::cout << e.what() << std::endl;
	}

	// -----------------------
	// Actualizar posición GUI
	// -----------------------
	update_ropot_position();
}


float SpecificWorker::calcularDistanciaMinima(const std::optional<RoboCompLidar3D::TPoints>& lidar_data)
{
	// Comprobamos si hay datos válidos
	if (!lidar_data.has_value() || lidar_data->empty())
	{
		qWarning() << "[calcularDistanciaMinima] No hay datos de LIDAR disponibles";
		return 1e6f;  // Valor grande por defecto
	}

	float distancia_minima = 1e6f;

	for (const auto& p : lidar_data.value())
	{
		if (p.phi >= FRONT_RIGHT_ANGLE && p.phi <= FRONT_LEFT_ANGLE) {
			float dist = std::hypot(p.x, p.y);
			if (dist < distancia_minima)
				distancia_minima = dist;
		}
	}


	qInfo() <<"Distancia minima: " << distancia_minima;
	return distancia_minima;
}

static constexpr int iter_seguras = 2;
static int contador = 0;
static float vector_media[iter_seguras];

std::tuple<SpecificWorker::RobotMode, float, float>
SpecificWorker::FORWARD_method(const std::optional<RoboCompLidar3D::TPoints>& filter_data)
{
	float advance_speed = 1000.0f;  // mm/s

	// Guardamos la distancia mínima en el vector circular
	vector_media[contador] = calcularDistanciaMinima(filter_data);
	contador = (contador + 1) % iter_seguras;  // avanza el índice y vuelve a 0

	// Si no hemos llenado suficientes iteraciones, seguimos FORWARD
	if (contador != 0)
		return {RobotMode::FORWARD, advance_speed, 0.0f};

	// Calculamos la media de las últimas 'iter_seguras' lecturas
	float suma = 0.0f;
	for (int i = 0; i < iter_seguras; ++i)
		suma += vector_media[i];

	float min_dist = suma / iter_seguras;

	if (min_dist < safe_distance)
	{
		advance_speed = 0.0f;
		return {RobotMode::TURN, advance_speed, 0.0f};
	}

	return {RobotMode::FORWARD, advance_speed, 0.0f};
}



std::tuple<SpecificWorker::RobotMode, float, float>
SpecificWorker::FOLLOW_WALL_method(const std::optional<RoboCompLidar3D::TPoints>& filter_data)
{
	if (!filter_data.has_value() || filter_data->empty())
		return {RobotMode::FOLLOW_WALL, 0, 0};

	float advance_speed = 800.0f; // mm/s
	float rotation_speed = 0.0f;

	float min_dist = calcularDistanciaMinima(filter_data);
	if (min_dist < safe_distance+50)
		return {RobotMode::TURN, 0.0f, 1.0f}; // giro para evitar obstáculo

	// Seguir la pared izquierda
	const float target_side_distance = 400.0f; // mm
	const float Kp = 0.004f;
	const float max_correction = 0.5f; // rad/s

	float side_dist = distanciaAnguloPromedio(filter_data, -90); // ángulo lateral
	float error = target_side_distance - side_dist;
	rotation_speed = std::clamp(error * Kp, -max_correction, max_correction);

	return {RobotMode::FOLLOW_WALL, advance_speed, rotation_speed};
}

std::tuple<SpecificWorker::RobotMode, float, float>
SpecificWorker::SPIRAL_method(const std::optional<RoboCompLidar3D::TPoints>& filter_data)
{
	float advance_speed = 800.0f; // mm/s
	float rotation_speed = 0.0f;

	// Lógica de movimiento en espiral la pondrás aquí
	return {RobotMode::SPIRAL, advance_speed, rotation_speed};
}

std::tuple<SpecificWorker::RobotMode, float, float>
SpecificWorker::TURN_method(const std::optional<RoboCompLidar3D::TPoints>& filter_data)
{
	srand((time(NULL)));
	float rotation_speed = 1.0f;;   // gira en el sitio
	float advance_speed = 0.0f;    // no avanza
	float min_dist = calcularDistanciaMinima(filter_data);

	// Mientras haya obstáculos cerca, sigue girando
	if (min_dist < safe_distance)
		return {RobotMode::TURN, advance_speed, rotation_speed};


	int probalidad = rand()%2;
	// Si ya hay espacio libre, decide siguiente modo
	if ( probalidad == 0) {
		qInfo() << "Foward";
		return {RobotMode::FORWARD, advance_speed, 0};
	}
	else {
		qInfo() << "Seguir pared";
		return {RobotMode::FOLLOW_WALL, advance_speed, 0};
	}
	return {RobotMode::FORWARD, advance_speed, 0};
}


std:: optional<RoboCompLidar3D::TPoints> SpecificWorker::filter_min_distance_cppitertools(const RoboCompLidar3D::TPoints& points)
{
	if (points.empty())
		return {};

	RoboCompLidar3D::TPoints result; result.reserve(points.size());
	for (auto&& [angle, group ]: iter::groupby(points, [](const auto& p)
		{float multiplier = std::pow(10.0f, 2); return std::floor(p.phi*multiplier)/multiplier;}))
	{
		auto min_it = std:: min_element(std::begin(group), std::end(group),
			[](const auto&a, const auto&b){return a.r < b.r;});
		result.emplace_back(RoboCompLidar3D::TPoint{.x=min_it->x, .y=min_it->y, .phi=min_it->phi});
	}
	return result;
}

// Devuelve la distancia promedio de los puntos LIDAR alrededor de un ángulo dado
float SpecificWorker::distanciaAnguloPromedio(const std::optional<RoboCompLidar3D::TPoints>& lidar_data, int ang)
{
	if (!lidar_data.has_value() || lidar_data->empty())
		return 1e6f;  // No hay datos disponibles

	float angF = static_cast<float>(ang);
	float distanciaAcum = 0.0f;
	int cont = 0;

	for (const auto& p : lidar_data.value())
	{
		if (p.phi >= angF - 0.05f && p.phi <= angF + 0.05f)
		{
			distanciaAcum += std::hypot(p.x, p.y);
			cont++;
		}
	}

	if (cont == 0)
		return 1e6f;

	return distanciaAcum / static_cast<float>(cont);
}



void SpecificWorker::emergency()
{
    std::cout << "Emergency worker" << std::endl;
    //emergencyCODE
    //
    //if (SUCCESSFUL) //The componet is safe for continue
    //  emmit goToRestore()
}



//Execute one when exiting to emergencyState
void SpecificWorker::restore()
{
    std::cout << "Restore worker" << std::endl;
    //restoreCODE
    //Restore emergency component

}


int SpecificWorker::startup_check()
{
	std::cout << "Startup check" << std::endl;
	QTimer::singleShot(200, QCoreApplication::instance(), SLOT(quit()));
	return 0;
}

void SpecificWorker::draw_lidar(const auto &points, QGraphicsScene* scene)
{
	static std::vector<QGraphicsItem*> draw_points;
	for (const auto &p : draw_points)
	{
		scene->removeItem(p);
		delete p;
	}
	draw_points.clear();

	const QColor color("LightGreen");
	const QPen pen(color, 10);
	//const QBrush brush(color, Qt::SolidPattern);
	for (const auto &p : points)
	{
		const auto dp = scene->addRect(-25, -25, 50, 50, pen);
		dp->setPos(p.x, p.y);
		draw_points.push_back(dp);   // add to the list of points to be deleted next time
	}
}



void SpecificWorker::update_ropot_position()
{
	try
	{
		RoboCompGenericBase:: TBaseState bState;
		omnirobot_proxy->getBaseState(bState);
		robot_polygon->setRotation(bState.alpha*180/M_PI);
		robot_polygon->setPos(bState.x, bState.z);
		std::cout << bState.alpha <<" " << bState.x << " " << bState.z << std::endl;
	}
	catch(const Ice::Exception &e){std::cout << e.what() << std::endl;}
}

void SpecificWorker::new_target_slot(QPointF p)
{
	qInfo() << "World coordinates" << p;
}

void SpecificWorker:: chocachoca(std::optional<RoboCompLidar3D::TPoints> filter_data,float &advance_speed,float &rotation_speed )
{
	const float FRONT_LEFT_ANGLE  = M_PI / 2;
	const float FRONT_RIGHT_ANGLE = -M_PI / 2;

	float min_dist = 1e6;

	for (const auto& p : filter_data.value())
	{
		if (p.phi >= FRONT_RIGHT_ANGLE && p.phi <= FRONT_LEFT_ANGLE)
		{
			float dist =std::hypot(p.x,p.y);
			if (dist < min_dist) min_dist = dist;
		}
	}

	float safe_distance = 450; // mm
	advance_speed = 600;  // mm/s
	rotation_speed = 0;   // rad/s

	if (min_dist < safe_distance)
	{
		advance_speed = 0;
		rotation_speed = 1;
	}
}



/**************************************/
// From the RoboCompLidar3D you can call this methods:
// RoboCompLidar3D::TData this->lidar3d_proxy->getLidarData(string name, float start, float len, int decimationDegreeFactor)
// RoboCompLidar3D::TDataImage this->lidar3d_proxy->getLidarDataArrayProyectedInImage(string name)
// RoboCompLidar3D::TDataCategory this->lidar3d_proxy->getLidarDataByCategory(TCategories categories, long timestamp)
// RoboCompLidar3D::TData this->lidar3d_proxy->getLidarDataProyectedInImage(string name)
// RoboCompLidar3D::TData this->lidar3d_proxy->getLidarDataWithThreshold2d(string name, float distance, int decimationDegreeFactor)

/**************************************/
// From the RoboCompLidar3D you can use this types:
// RoboCompLidar3D::TPoint
// RoboCompLidar3D::TDataImage
// RoboCompLidar3D::TData
// RoboCompLidar3D::TDataCategory

/**************************************/
// From the RoboCompOmniRobot you can call this methods:
// RoboCompOmniRobot::void this->omnirobot_proxy->correctOdometer(int x, int z, float alpha)
// RoboCompOmniRobot::void this->omnirobot_proxy->getBasePose(int x, int z, float alpha)
// RoboCompOmniRobot::void this->omnirobot_proxy->getBaseState(RoboCompGenericBase::TBaseState state)
// RoboCompOmniRobot::void this->omnirobot_proxy->resetOdometer()
// RoboCompOmniRobot::void this->omnirobot_proxy->setOdometer(RoboCompGenericBase::TBaseState state)
// RoboCompOmniRobot::void this->omnirobot_proxy->setOdometerPose(int x, int z, float alpha)
// RoboCompOmniRobot::void this->omnirobot_proxy->setSpeedBase(float advx, float advz, float rot)
// RoboCompOmniRobot::void this->omnirobot_proxy->stopBase()

/**************************************/
// From the RoboCompOmniRobot you can use this types:
// RoboCompOmniRobot::TMechParams

